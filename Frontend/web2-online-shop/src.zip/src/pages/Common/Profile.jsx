import { useState, useEffect, useRef } from 'react';
import { Link as RouterLink } from 'react-router-dom';

import {
  Button,
  Container,
  Link,
  MenuItem,
  Paper,
  Select,
  TextField,
  Typography,
  InputLabel,
  FormControl,
  Box,
} from '@mui/material';

import Calendar from '../../components/Calendar';
import UploadButtons from '../../components/UploadButton';
import {
  formatDateTime,
  getDateString,
  getIsoString,
} from '../../utils/dateTimeUtils';
import MyBackdrop from '../../components/MyBackdrop';
import useServices from '../../services/useServices';

import styles from '../../style/authStyles';
import { toasterUtil as toaster } from '../../utils/toasterUtil';

const Profile = () => {
  const [basicUserInfo, setBasicUserInfo] = useState(basicUserInit);
  const [validity, setValidity] = useState(fieldValidity);
  const [fetchingProfile, setFetchingProfile] = useState(true);
  const [updatingProfile, setUpdatingProfile] = useState(false);
  const {
    getUserProfileRequest,
    updateUserRequest,
    clearRequest,
    isLoading,
    data,
    error,
    statusCode,
  } = useServices();

  const handleProfileUpdate = (event) => {
    event.preventDefault();

    setValidity(validateFields(basicUserInfo));

    console.log(basicUserInfo.birthdate);

    for (const field in validity) {
      if (validity[field].error) {
        return;
      }
    }

    setUpdatingProfile(true);
    updateUserRequest(basicUserInfo);
  };

  useEffect(() => {
    getUserProfileRequest();
  }, [getUserProfileRequest]);

  useEffect(() => {
    if (isLoading) {
      return;
    } else if (statusCode === 200 && !error && data && fetchingProfile) {
      setFetchingProfile(false);
      setBasicUserInfo(data);
      clearRequest();
    } else if (statusCode === 200 && !error && updatingProfile) {
      setUpdatingProfile(false);
      setFetchingProfile(true);
      getUserProfileRequest();
      toaster.handleSuccess('Successfully updated profile!');
      clearRequest();
    } else if (statusCode !== 200 && error) {
      toaster.handleError(statusCode, error);
      clearRequest();
    }
  }, [
    isLoading,
    statusCode,
    error,
    data,
    fetchingProfile,
    clearRequest,
    getUserProfileRequest,
    updatingProfile,
  ]);

  console.log(basicUserInfo.birthdate);

  return (
    <>
      <Container sx={{ ...styles.container }}>
        <Paper component='form' sx={{ ...styles.paper }} elevation={4}>
          <Box sx={styles.rowBox}>
            <TextField
              placeholder='Username'
              id='username'
              value={basicUserInfo.username}
              error={validity.username.error}
              helperText={validity.username.helper}
              sx={styles.textField}
              onChange={(e) => {
                setBasicUserInfo((old) => {
                  return { ...old, username: e.target.value };
                });
              }}
              required
            />
            <TextField
              placeholder='Email'
              id='email'
              value={basicUserInfo.email}
              error={validity.email.error}
              helperText={validity.email.helper}
              sx={styles.textField}
              type='email'
              onChange={(e) => {
                setBasicUserInfo((old) => {
                  return { ...old, email: e.target.value };
                });
              }}
              required
            />
          </Box>
          <Box sx={styles.rowBox}>
            <TextField
              placeholder='Firstname'
              id='firstname'
              value={basicUserInfo.firstname}
              error={validity.firstname.error}
              helperText={validity.firstname.helper}
              sx={styles.textField}
              onChange={(e) => {
                setBasicUserInfo((old) => {
                  return { ...old, firstname: e.target.value };
                });
              }}
              required
            />
            <TextField
              placeholder='Lastname'
              id='lastname'
              value={basicUserInfo.lastname}
              error={validity.lastname.error}
              helperText={validity.lastname.helper}
              sx={styles.textField}
              onChange={(e) => {
                setBasicUserInfo((old) => {
                  return { ...old, lastname: e.target.value };
                });
              }}
              required
            />
          </Box>
          <Box sx={styles.rowBox}>
            <TextField
              placeholder='Address'
              id='address'
              value={basicUserInfo.address}
              error={validity.address.error}
              helperText={validity.address.helper}
              sx={styles.textField}
              onChange={(e) => {
                setBasicUserInfo((old) => {
                  return { ...old, address: e.target.value };
                });
              }}
              required
            />
            <Calendar
              label='Birthdate'
              id='birthdate'
              sx={styles.textField}
              value={basicUserInfo.birthdate}
              error={validity.birthdate.error}
              helperText={validity.birthdate.helper}
              disableFuture={true}
              callback={(date) => {
                console.log(date);
                date = date == null ? null : getIsoString(date);
                console.log(date);
                setBasicUserInfo((old) => {
                  return { ...old, birthdate: date };
                });
              }}
            />
          </Box>
          <Button
            sx={{ width: '30%', marginTop: '15px', alignSelf: 'center' }}
            variant='contained'
            type='submit'
            onClick={(event) => {
              handleProfileUpdate(event);
            }}
          >
            Update
          </Button>
        </Paper>
      </Container>
      <MyBackdrop open={isLoading} />
    </>
  );
};

var basicUserInit = {
  username: '',
  email: '',
  firstname: '',
  lastname: '',
  address: '',
  birthdate: '',
};

const fieldValidity = {
  username: {
    error: false,
    helper: '',
  },
  email: {
    error: false,
    helper: '',
  },
  firstname: {
    error: false,
    helper: '',
  },
  lastname: {
    error: false,
    helper: '',
  },
  address: {
    error: false,
    helper: '',
  },
  birthdate: {
    error: false,
    helper: '',
  },
};

const validateFields = (user) => {
  const updatedFieldValidity = { ...fieldValidity };

  const requiredFields = Object.keys(fieldValidity);

  requiredFields.forEach((field) => {
    if (!user[field]) {
      updatedFieldValidity[field].error = true;
      updatedFieldValidity[field].helper = 'Field is required';
    } else if (user[field].length < 3) {
      updatedFieldValidity[field].error = true;
      updatedFieldValidity[field].helper = 'Too short';
    } else {
      updatedFieldValidity[field].error = false;
      updatedFieldValidity[field].helper = '';

      // Check email format
      if (field === 'email') {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(user.email)) {
          updatedFieldValidity.email.error = true;
          updatedFieldValidity.email.helper = 'Invalid email format';
        }
      }

      // Check password and repeatPassword
      if (user.password !== user.repeatPassword) {
        updatedFieldValidity.password.error = true;
        updatedFieldValidity.password.helper = 'Passwords do not match';
        updatedFieldValidity.repeatPassword.error = true;
        updatedFieldValidity.repeatPassword.helper = 'Passwords do not match';
      }

      // Check birthdate is in the future
      if (field === 'birthdate') {
        const today = new Date();
        const birthdate = new Date(user.birthdate);
        if (birthdate > today) {
          updatedFieldValidity.birthdate.error = true;
          updatedFieldValidity.birthdate.helper =
            'Birthdate must be in the past';
        }
      }
    }
  });

  return updatedFieldValidity;
};

export default Profile;
