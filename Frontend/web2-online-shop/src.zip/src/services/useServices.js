import { useCallback } from 'react';
import useHttp from '../hooks/useHttp';

const useServices = () => {
  const {
    data,
    isLoading,
    error,
    statusCode,
    getRequest,
    postRequest,
    postRequestFormData,
    putRequest,
    putRequestFormData,
    resetHttp,
  } = useHttp();
  const baseUrl = process.env.REACT_APP_API_BASE_URL;
  const registerUrl = baseUrl + process.env.REACT_APP_API_REGISTER_URL;
  const loginUrl = baseUrl + process.env.REACT_APP_API_LOGIN_URL;
  const getUserUrl = baseUrl + process.env.REACT_APP_API_GET_USER_URL;
  const updateUserUrl = baseUrl + process.env.REACT_APP_API_UPDATE_USER_URL;

  const registerRequest = useCallback(
    (user) => {
      postRequestFormData(registerUrl, user);
    },
    [postRequestFormData, registerUrl]
  );

  const loginRequest = useCallback(
    (credentials) => {
      postRequest(loginUrl, credentials);
    },
    [postRequest, loginUrl]
  );

  const getUserProfileRequest = useCallback(() => {
    getRequest(getUserUrl);
  }, [getRequest, getUserUrl]);

  const updateUserRequest = useCallback(
    (user) => {
      putRequest(updateUserUrl, user);
    },
    [putRequest, updateUserUrl]
  );

  return {
    data,
    isLoading,
    error,
    statusCode,
    clearRequest: resetHttp,
    registerRequest,
    loginRequest,
    getUserProfileRequest,
    updateUserRequest,
  };
};

export default useServices;
